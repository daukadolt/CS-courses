package kz.edu.nu.cs.se.hw.kwic;

public interface Indexable {
    public String getEntry();
    
    public int getLineNumber();
}
