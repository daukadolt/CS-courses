package kz.edu.nu.cs.se.hw.rummy.states;

public enum Steps {
    DRAW, MELD, DISCARD, RUMMY, WAITING, FINISHED;
}
