#Author: Dinh-Mao Bui, Anh-Tu Nguyen
#Rule of traversing: Alphabetical ordered, then left to right, 
#Points: 2
def traverse(tree, init):    	
	queue = [init]
	traversed = []
	visited = set()
	while queue:
		'''
			Student fixes the loopy path from here to the end of this function
		'''
		node = queue.pop(0)
		if node in visited:
			continue
		visited.add(node)
		traversed.append(node)
		leaves = [leave for leave in tree[node] if leave not in visited]
		for leaf in leaves:
			queue.append(leaf)
	return traversed

#Points: 3
def pathfinder(tree, init, goal):
	traversed = []
	queue = [init]
	if init == goal:
		return "No kidding, pls"
	visited = set()
	nodeParents = {}
	distanceFromRoot = {init: 0}
	while queue:
		'''
			You implement the path finder from here
		'''
		node = queue.pop(0)
		if node == goal:
			traversed.append(node)
			print(nodeParents)
			print(distanceFromRoot)
			return traversed
		if node in visited:
			continue
		visited.add(node)
		traversed.append(node)
		leaves = [leave for leave in tree[node] if leave not in visited]
		for leave in leaves:
			if leave in distanceFromRoot:
				if distanceFromRoot[leave] > distanceFromRoot[node] + 1:
					distanceFromRoot[leave] = distanceFromRoot[node] + 1
			else:
				distanceFromRoot[leave] = distanceFromRoot[node] + 1

			if leave in nodeParents and node not in nodeParents[leave]:
				nodeParents[leave].add(node)
			elif leave not in nodeParents:
				nodeParents[leave] = set()
				nodeParents[leave].add(node)
			queue.append(leave)
		
	return "No such path exists"
 
